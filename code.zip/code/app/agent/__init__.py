"""LangGraph-based support agent."""
